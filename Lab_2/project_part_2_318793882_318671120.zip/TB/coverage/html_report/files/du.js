var g_data = {"data":[{"n":"work.tb_top","id":1,"zf":1,"tc":100.00,"g":100.00,"a":100.00}]};
processDuData(g_data);