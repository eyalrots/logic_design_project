var g_data = {"1":["work.tb_top",100.00,1]};
processDuLinks(g_data);