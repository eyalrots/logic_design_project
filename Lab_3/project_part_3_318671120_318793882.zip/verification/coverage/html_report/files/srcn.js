var g_data = ["","TB/fsm_tb.sv","DUT/fsm.sv","DUT/sub_type.sv","DUT/sbox.sv","DUT/shift_rows.sv","DUT/Mix_columns.sv","DUT/Mix_operation.sv"];
processSrcNamesData(g_data);